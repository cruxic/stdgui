===========
Snap Layout
===========

User interface *layout* is the task of determining the size and position of widgets, (buttons, text-boxes, etc), within the window.  *Snap Layout* is stdgui's solution for GUI layout.

The simplest form of GUI layout is to use fixed X,Y pixel coordinates and sizes.  This cannot work for stdgui for two primary reasons:
1.  The natural size of buttons and other widgets varies between platforms.
2.  As windows are resized, the widgets within need to adapt to, and make the best use of, available space.
So, instead of fixed layout, stdgui computes the layout at runtime according to the rules and parameters which you have specified.
TODO: link to discussion of alternative layout managers and why stdgui made the choices it did

HBoxes and VBoxes
-----------------

Snap Layout uses boxes.  Boxes contain widgets or other, nested, boxes.  There are two types of boxes: ``hbox`` and ``vbox``.  ``hbox`` lays out its contents horizontally, left-to-right:

IMAGE

::

<hbox>
	<button>Horizontal</button>
	<button>Layout</button>
</hbox>

Conversely, ``vbox`` does vertical layout, top-to-bottom:

IMAGE

::
<vbox>
	<button>Vertical</button>
	<button>Layout</button>
</vbox>

No two widgets can be side-by-side in a ``vbox``.  To achieve this you must nest an ``hbox`` within:

IMAGE

::
<vbox>
	<hbox>
		<button>Nested</button>
		<button>hbox</button>
	</hbox>
	<button>Inside a vbox</button>
</vbox>

The same concept applies to hboxes.

Snapping
--------

hboxes always fill the horizontal space of their parent window (or box), but vertically, they are only as tall as the tallest child widget (or nested box).  The same principle applies to vboxes except they fill the vertical space but are only as wide as the widest child.

IMAGE

This implies that we have some extra space to play with.  Within a box, widgets can be *snapped* toward any edge of the box.

You can snap left (**L**) or right (**R**):
IMAGE

::
<hbox>
	<button snap="L">Hello</button>
	<button snap="R">World</button>
	<select snap="R" lines="3">
		<option>Red</option>
		<option>Green</option>
		<option>Blue</option>
	</select>
</hbox>

And you can snap top (**T**) or bottom (**B**):
IMAGE

::
<hbox>
	<button snap="T">Hello</button>
	<button snap="B">World</button>
	<select lines="3">
		<option>Red</option>
		<option>Green</option>
		<option>Blue</option>
	</select>
</hbox>

And, any combination of snaps is legal:

IMAGE

::
<hbox>
	<button snap="LT">Hello</button>
	<button snap="TB">World</button>
	<select snap="RB" lines="3">
		<option>Red</option>
		<option>Green</option>
		<option>Blue</option>
	</select>
</hbox>

Note: The order in which snaps are listed has no meaning.  Thus, ``snap="LT"` is the same as ``snap="TL"``.
TODO: should I talk about the principle that order of declaration in the XML maps directly to order of appearence?

Spanners
--------

When you apply two opposing snaps it creates what is called a *spanner*.  Spanners are used whenever you want a widget to stretch as the window is resized.  In the previous example, the "World" button is a spanner because it snaps to both the top and bottom of it's parent hbox.  Here is a left and right spanner which spans the space between two widgets:

IMAGE

::
<hbox>
	<button snap="L">Snap L</button>
	<button snap="LR">Snap LR</button>
	<button snap="R">Snap R</button>
</hbox>

If two or more spanners occupy the same space, they share it evenly:

IMAGE

<hbox>
	<button snap="L">Snap L</button>
	<button snap="LR">Snap LR</button>
	<button snap="LR">Snap LR</button>
	<button snap="R">Snap R</button>
</hbox>

TODO: refine this
As you can see, snaps are like magnetic forces which cause the edges of a widget to push out until it hits something.  (In fact, the inspiration for "snap layout" came from the sound of two magnets snapping together.)  Spanners have the lowest snapping force and thus are disabled if other widgets snap against them.

Centering
---------



multiple spanners
disabled spanners

centering
