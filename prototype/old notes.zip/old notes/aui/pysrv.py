from os import curdir, sep
from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
import handler

class MyHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        try:
	        print self.path
	        f = open(curdir + sep + self.path) #self.path has /test.html
	        d = handler.loadDoc(f)
	        s = handler.genForm(d)
	        self.send_response(200)
	        self.send_header('Content-type',	'text/plain')
	        self.end_headers()
	        #self.wfile.write(f.read())
	        self.wfile.write(s)
	        f.close()
        except:
            import traceback
            #print str(sys.exc_info()[2])
            traceback.print_exc()
            self.send_error(500, "Unexpected error")

def main():
    try:
        server = HTTPServer(('', 8080), MyHandler)
        print 'Welcome to the machine...'
        server.serve_forever()
    except KeyboardInterrupt:
        print '^C received, shutting down server'
        server.socket.close()

if __name__ == '__main__':
    main()
