import sys
from xml.dom.ext.reader import Sax2

def loadDoc(f):
	# create Reader object
	reader = Sax2.Reader()

	# parse the document
	return reader.fromStream(f)
	
def genForm(aui):
	from cStringIO import StringIO
	from xml.dom.NodeFilter import NodeFilter

	walker = aui.createTreeWalker(aui.documentElement, NodeFilter.SHOW_ELEMENT, None, 0)
	sb = StringIO()
	while True:
		sb.write(walker.currentNode.tagName)
		next = walker.nextNode()
		if next is None: break
		
	return sb.getvalue()
	

