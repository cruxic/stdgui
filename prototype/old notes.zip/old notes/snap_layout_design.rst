==========================
Snap Layout Design Details
==========================
*Revision 0. June 2012. By Adam Bennett.*

The job of a layout manager is to set the position (x,y) and size (width & height) of form components according to rules.  *Snap Layout* is the name of the layout manager used by stdgui.  This document describes how Snap Layout works and the reasoning behind it's design.

Quick Start
-----------

The inspiration for Snap Layout came from magnets and the sound they make when they "snap" together.  The idea is this:

Every item on the form (aka component or control) is treated like a rectangle with 4 sides: **T**\ op, **B**\ ottom, **L**\ eft and **R**\ ight.  Any given side can be "snapped" to the side of an adjacent item or the containing window.  Like magnets!

TODO: image of rectangle showing the four sides and their letter.  Emphasize the magnet effect.

As a first example let's place items in the four corners of our window like so:

TODO: IMAGE

Snap Layout is written in XML.  Here's how to create the above layout::

	<?xml version="1.0" encoding="UTF-8"?>
	<layout>
		<A snap="TL"/>
		<B snap="TR"/>
		<C snap="BL"/>
		<D snap="BR"/>
	</layout>


Now lets say we wanted to center an item between the top two items and stretch an item between the bottom two:

todo: image

The XML::

	<?xml version="1.0" encoding="UTF-8"?>
	TODO


Three goals drove the design of Snap Layout:
	1. Powerful enough to layout the majority of user-interfaces.  Programmers should not be forced to mix multiple layout managers (eg Java Swing). 
	2. Simple enough that layouts can be created by hand, without the assistance of a GUI builder tool.  This is important because many applications have need to create layouts procedurally, which means the layout paradigm must be easy to conceptualize. 
	3. No pixel coordinates.  Layout needs to dynamically account for variables such as: window size, font-size, and the platforms preferred sizes for UI components such as buttons and checkboxes. 

Some secondary goals included: 
	* Keep GUI builders in mind.  Most people will want to use a GUI builder.
	* When creating layouts by hand, the less typing the better.
	* Layouts should be no harder to read than they were to write.

The inspiration for Snap Layout came from magnets and the sound they make when they "snap" together.  The idea is this:

Every item on the form (aka component or control) is treated like a rectangle with 4 sides: Top, Bottom, Left and Right.  Any given side can be "snapped" to the side of an adjacent item or the containing window.  Like magnets :)

Let's start with an example.  The following layout places items in all four corners of the box::

	_____________
	|A         B|
	|           |
	|           |
	|           |
	|C         D|
	-------------

	<layout>
		<A snap="TL"/>
		<B snap="TR"/>
		<C snap="BL"/>
		<D snap="BR"/>
	</layout>

**Principles:**
	1. All items are assumed to be four sided rectangles.  Thus every item has a Top, Bottom, Left, and Right side. 
	2. An item can be "snapped" to it's surroundings using any combination of it's four sides. 
	3. The order in which the snaps are declared does not matter.  ``snap="TL"`` is the same as ``snap="LT"``.

The Problem with physical layout
--------------------------------

It's tempting to model layout after objects in our physical world.  By this I mean, pretend all the buttons, checkboxes, and text fields were tangible physical items you could hold in your hand.  The have width and height.  You could then lay them all out on a table and move them around until you get the look you want.

The flaw with this model is that GUI controls don't have a fixed width and height.  For example, the size of a button depends on these things:
	#. The number of characters of button text.  (Which is certain change with translations.)
	#. The font size of the button text.
	#. The GUI toolkit which is rendering the button (different paddings around the text).

In short, GUI components have an undefined size.

Because of this fact, we cannot "snap" components like this::

	_____________
	|______|    |
	|___||____| |
	|           |
	|           |
	-------------

The width of the red component is undefined and therefore the blue component might not "catch" it when it's snapping to the top::

	_____________
	|__|____|   |
	|___|       |
	|           |
	|           |
	-------------

The other problem with thinking in terms of physical objects is that, when snapping, where do the objects start from?
TODO: articulate this.

In summary we need an abstract model for layout that makes no assumptions about the size of components nor where they originate from when they snap into place.


Row Centric Layout
------------------

Instead of a physically based model, Snap Layout adopts a so called "row centric" layout model.

	In the row centric model, components are laid out from **left-to-right**, **top-to-bottom**.

And, within a given row, each component has it's own vertical column.

	No two components are allowed to overlap vertically within a row.

These are the two principles of row centric layout.  Here's how rows are denoted in the XML::

	<br/>

This break is actually syntactical sugar for creating a sub box.



A Fundamental Ambiguity
-----------------------


There is a fundamental ambiguity that must be solved when using this snapping paradigm.  Consider this layout::

	<layout>
		<A snap="TL"/>
		<B snap="TL"/>
	</layout>

Which of the following is correct?::

	_____________
	|AB         |
	|           |
	|           |
	|           |
	|           |
	-------------
	
	_____________
	|A          |
	|B          |
	|           |
	|           |
	|           |
	-------------

Either could be correct - it's ambiguous.  One way to resolve the ambiguity would be to say that the order in which the snaps are declared matters.  If we did this then the first choice is the correct one because ``B`` snaps to the top *first* and then to the left.  However, Snap Layout avoids this solution because it makes the layout more subtle and thus harder to read and visualize.  Instead, Snap Layout has removes the ambiguity with a "break" (``<br/>``) like so::

	<layout>
		<A snap="TL"/>
		<br/>
		<B snap="TL"/>
	</layout>

The break forces the second layout, putting ``B`` on a separate line.  The implication here is that:
	
	Items are placed **left to right** until a break is encountered.

here: columns

Let's add to our example:

_____________
|A    E    B|
|           |
|F    G    H|
|           |
|C    I    D|
-------------

<layout>
	<A snap="TL"/>
	<E snap="T"/>
	<B snap="TR"/>
	<br/>

	<F snap="L"/>
	<G/>
	<H snap="R"/>
	<br/>

	<C snap="BL"/>
	<I snap="B"/>
	<D snap="BR"/>
</layout>

Principles:
HERE********: tell what <br/> does.
1) Items which ommit snaps on the horizontal or vertical axis become centered on that axis.  In other words, if neither Left nor Right snaps are declared then the item will be centered horizontally between the items which border it.  Similarly, if Bottom and Top are ommitted the item will be centered vertically.
2) If zero snaps are declared the item is centered both horizontally and vertically between the items which border it.
3) <X snap=""/> is the same as <X/>

Preferred Size
--------------
All items must have a "preferred size".  Items are always sized to their preferred size unless:
	1. The window is to small
	2. The item is a spanner

When too little room, items are shrunk below their preferred size using this policy:
	1. If spanners exist they are reduced first according to their elasticity ratio.
	2. Remaining are reduced propotionally to their preferred size.  This means that larger items shrink the fastest and smaller items more slowly.

Items are never shrunk smaller than 1 pixel.  Specification of min and max sizes are not helpful to Snap Layout.  Probably less portable too.  Perhaps, however we can add a "reluctant" flag to controls which should be shrunk last (such as image icons).

Implicit box snaps
------------------
A <br/> ends an implicit box.  The snaps of the box are the union of the snaps of each item within.  You can override this by using a <box> which declares the snaps explicitly.

Spanner
-------
A "spanner" is any item with opposing snaps (TB or LR).  If excess size is available it is allocated to each spanner equally (by default).  User can override by declaring the elasticity ratio.


next topics:
stacked items (in either direction)
spanners
sub boxes
alignment within the row.  in short, if any control spans vertically the row itself will too.  To avoid this use a sub box.


Notes: items with the same vertical snap will be baseline aligned if applicable (labels, textboxes).


